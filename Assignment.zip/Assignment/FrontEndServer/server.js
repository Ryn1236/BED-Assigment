/*
Name: Bryan Sung Jing Jie
Admin ID: P2241418
Class: DISM/FT/2B/24
Module code: ST0503

Summary: The server.js is used to start the  frontend server and website.
*/

//const app = require('./controller/app');
const express=require('express');
const serveStatic=require('serve-static');

var hostname="localhost";
var port=3001;

var app=express();

app.use(function(req,res,next){
    console.log(req.url);
    console.log(req.method);
    console.log(req.path);
    console.log(req.query.id);

    if(req.method!="GET"){
        res.type('.html');
        var msg="<html><body>This server only serves web pages with GET!</body></html>";
        res.end(msg);
    }else{
        next();
    }
});


app.use(serveStatic(__dirname+"/public"));


app.listen(port,hostname,function(){

    console.log(`Server hosted at http://${hostname}:${port}`);
});