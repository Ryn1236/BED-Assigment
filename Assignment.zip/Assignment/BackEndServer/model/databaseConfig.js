/*
Name: Bryan Sung Jing Jie
Admin ID: P2241418
Class: DISM/FT/2B/24
Module code: ST0503

Summary: The databaseConfig.js is used to create the connection with the server.
*/


var mysql =require('mysql');
var dbconnect = {

    getConnection: function () {

        var conn = mysql.createConnection({

            host: "localhost",
            user: "root",
            password: "Pa$$w0rd",
            database: "sp_games"
        })
        return conn;
    }
}

module.exports = dbconnect