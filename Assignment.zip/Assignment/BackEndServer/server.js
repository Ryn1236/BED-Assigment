/*
Name: Bryan Sung Jing Jie
Admin ID: P2241418
Class: DISM/FT/2B/24
Module code: ST0503

Summary: The server.js is used to start the backend server.
*/

var express = require('express');
var serveStatic = require('serve-static');
var app = require('./controller/app.js');

var port = 8081;

app.use(serveStatic(__dirname + '/public')); 

var server = app.listen(port, function(){
    console.log('Web App Hosted at http://localhost:%s', port);
});